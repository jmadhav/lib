#!/bin/sh

export DEV=/Developer/Platforms/iPhoneOS.platform/Developer
export SDK=${DEV}/SDKs/iPhoneOS3.1.sdk

pushd ${DEV}/usr/bin
rm  /Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-gcc
rm  /Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-g++
rm  /Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-ranlib
ln -s arm-apple-darwin9-gcc-4.0.1 arm-apple-darwin9-gcc
ln -s arm-apple-darwin9-g++-4.0.1 arm-apple-darwin9-g++
ln -s ranlib arm-apple-darwin9-ranlib
popd

export PATH=${DEV}/usr/bin:${PATH}

export CFLAGS="-O2 -arch armv6 -isysroot ${SDK}"

export LDFLAGS="-O2 -arch armv6 -isysroot ${SDK}"

export CPP="${DEV}/usr/bin/cpp"

./aconfigure --host=arm-apple-darwin9 --disable-ssl \
--disable-ilbc-codec CFLAGS="-arch armv6 -pipe -O0 -isysroot \
 /Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS3.1.sdk \
-I/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS3.1.sdk/usr/include/gcc/darwin/4.0" \
LDFLAGS="-isysroot /Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS3.0.sdk \
-L/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/IphoneOS3.1.sdk/usr/lib" \
CPP=/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-cpp \
AR=/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-ar \
RANLIB=/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-ranlib \
CC=/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-gcc
  

#make dep
#make
