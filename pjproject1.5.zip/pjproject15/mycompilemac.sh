#!/bin/sh
export DEV=/Developer/
export SDK=${DEV}/SDKs/MacOSX10.5.sdk
find . -name "*.depend" -print -exec rm -f {} \;

find . -name "*i786*.a" -print -exec rm -f {}  \;
find . -name "*.o" -print -exec rm -f {}  \;
pushd ${DEV}/usr/bin

rm  /Developer/Platforms/usr/bin/i786-apple-darwin9-gcc
rm  /Developer/Platforms/usr/bin/i786-apple-darwin9-g++
rm  /Developer/Platforms/usr/bin/i786-apple-darwin9-ranlib
echo pwd

ln -s gcc-4.2 i786-apple-darwin9-gcc
ln -s gcc-4.2 i786-apple-darwin9-g++
ln -s ranlib i786-apple-darwin9-ranlib
popd

export PATH=${DEV}/usr/bin:${PATH}

#export CFLAGS="-O2 -arch i386 -isysroot ${SDK}"

export  CFLAGS="-arch i386 -DPA_USE_COREAUDIO=1  -pipe -O0 -isysroot  /Developer/SDKs/MacOSX10.5.sdk -I $SDK/usr/include/gcc/darwin/4.0"

export LDFLAGS="-O2 -arch i386 -isysroot ${SDK}"
#export LDFLAGS="-isysroot $SDK -L $SDK/usr/lib" 
export CPP="${DEV}/usr/bin/cpp"

./aconfigure --host=i786-apple-darwin9  --disable-ssl \
--disable-speex-aec   --disable-l16-codec --disable-g722-codec \
--disable-ilbc-codec \
#CPP=/Developer/Platforms/iPhoneSimulator.platform/Developer/usr/bin/i386-apple-darwin9-cpp \
#AR=/Developer/usr/bin/i386-apple-darwin9-ar \
RANLIB=/Developer/usr/bin/i386-apple-darwin9-ranlib \
CC=/Developer/usr/bin/i386-apple-darwin9-gcc
  

make dep
make
