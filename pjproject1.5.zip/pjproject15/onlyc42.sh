#!/bin/sh

export DEV=/Developer/Platforms/iPhoneOS.platform/Developer
export SDK=${DEV}/SDKs/iPhoneOS3.1.sdk
#find . -name "*.depend" -print -exec rm -f {} \;
#find . -name "*arm*.a" -print -exec rm -f {}  \;
#find . -name "*.o" -print -exec rm -f {}  \;

pushd ${DEV}/usr/bin


rm  /Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-gcc
rm  /Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-g++
rm  /Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/arm-apple-darwin9-ranlib

ln -s gcc-4.2 arm-apple-darwin9-gcc
ln -s gcc-4.2 arm-apple-darwin9-g++
ln -s ranlib arm-apple-darwin9-ranlib
popd

export PATH=${DEV}/usr/bin:${PATH}

export CFLAGS="-O2 -arch armv6 -isysroot ${SDK}"

export LDFLAGS="-O2 -arch armv6 -isysroot ${SDK}"

export CPP="${DEV}/usr/bin/cpp"
make
