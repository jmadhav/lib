#undef PJ_HAS_FLOATING_POINT
#define PJ_HAS_FLOATING_POINT   1

/* SRTP has not been ported to iPhone yet */
#   undef PJMEDIA_HAS_SRTP
#   define PJMEDIA_HAS_SRTP             0

/* Disable some codecs for now */
#   define PJMEDIA_HAS_GSM_CODEC        1
#   define PJMEDIA_HAS_L16_CODEC        0
#   define PJMEDIA_HAS_ILBC_CODEC       0
#   define PJMEDIA_HAS_SPEEX_CODEC      0
#   define PJMEDIA_HAS_G722_CODEC       0
